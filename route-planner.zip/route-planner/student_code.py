def shortest_path(M,start,goal):
    print("shortest path called")
    return