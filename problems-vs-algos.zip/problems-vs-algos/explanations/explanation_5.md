# Code design 
In this problem I decided to implent a Trie or Prefix Tree due to its structure that store a dynamic set of strings.

    
# Time Efficiency
Time Efficiency for this problem is `O(m*n)` m being the number of characters  in a word and n being the number of words

# Space Complexity
Space complexity of this problem `O(n)`
