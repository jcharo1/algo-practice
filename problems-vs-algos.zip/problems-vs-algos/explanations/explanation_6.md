# Code design 
In this problem I decided to travese the list and update max and min values in a single traversal


    
# Time Efficiency
Time Efficiency for this problem is `O(n)` 

# Space Complexity
Space complexity of this problem is constant or `O(n)`