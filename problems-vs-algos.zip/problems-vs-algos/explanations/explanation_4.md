# Code design 
In this problem I decided to initilze three pointers that travase through the list in a single-traversal 

    
# Time Efficiency
Time Efficiency for this problem is `O(n)`
# Space Complexity
Space complexity of this problem is constant or `O(1)`
