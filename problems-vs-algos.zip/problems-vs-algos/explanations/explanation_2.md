# Code design 
In this problem I decided to use binary search algorithms to split the list and search for the index of the target number.
    
# Time Efficiency
Time Efficiency for this problem is `O(log(n))`
# Space Complexity
Space complexity of this problem is `O(1)`
