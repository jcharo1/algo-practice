# Code design 
In this problem I decided to use a binary search algorithm due expected time complexity of `O(log(n))`
    
# Time Efficiency
Time Efficiency for this problem is `O(log(n))`
# Space Complexity
Space complexity of this binary search  is  constant or `O(1)`.
