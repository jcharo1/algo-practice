# Code design 
In this problem I decided to use recursive binary search to split the list and search for the index of the target number.
    
# Time Efficiency
Time Efficiency for this problem is `O(log(n))`
# Space Complexity
Space complexity of recursive binary search is constant or  `O(1)`
