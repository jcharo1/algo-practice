# Code design 
In this problem I decided to implent a Trie or Prefix Tree due to its structure that store a dynamic set of strings.

# Time and Space Complexity 

TrieNode's time complexity and space complexity to insert a character is O(1).
TrieNode's time complexity and space complexity of suffixes of a node is O(M*N).

Trie's time complexity and space complexity to insert a word is O(n).
Trie's time complexity to find a prefix is O(n) and space complexity is O(1).
