# Code design 
In this problem I decided to use merge sort to arrange elements in ascending order.
    
# Time Efficiency
Time Efficiency for this problem is `O(nlog(n))`
# Space Complexity
Space complexity of this problem is `O(n)`
